from app import db
import models
from flask import Flask, redirect, url_for, render_template, request, flash
from flask_sqlalchemy import SQLAlchemy


def delete_by_item_id(model, temp):
     model.query.filter_by(item_id = temp).delete()
	

def delete_by_staff_id(model, temp):
     model.query.filter_by(staff_id = temp).delete()




