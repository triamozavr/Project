from app import db


class Items(db.Model):
	__tablename__ = 'item'

	id = db.Column(db.Integer, primary_key=True)
	name = db.Column(db.String())
	status = db.Column(db.String())
	has_passport = db.Column(db.Boolean())
	b_place = db.Column(db.String())
	b_date = db.Column(db.Date())
	warranty = db.Column(db.Date())

	def __init__(self, name, status, has_passport, b_place, b_date, warranty):
		self.name = name
		self.status = status
		self.has_passport = has_passport
		self.b_place = b_place
		self.b_date = b_date
		self.warranty = warranty

	def __repr__(self):
		return '<id {}>'.format(self.id)

	def serialize(self, template):
		i = {'id': self.id, 'name': self.name, 'status': self.status, 'has_passport': self.has_passport, 'b_place': self.b_place, 'b_date': self.b_date, 'warranty': self.warranty}
		lst = [None] * len(template)
		for key, value in i.items():
			for j in range(len(template)):
				if template[j] == key:
					lst[j] = value
					break
		return lst


class Staff(db.Model):
	__tablename__ = 'staff'

	staff_id = db.Column(db.Integer(), primary_key=True)
	staff_name = db.Column(db.String())
	staff_position = db.Column(db.String())
	staff_status = db.Column(db.Integer())

	def __init__(self, staff_name, staff_position, staff_status):
		self.staff_name = staff_name
		self.staff_position = staff_position
		self.staff_status = staff_status

	def __repr__(self):
		return '<id {}>'.format(self.staff_id)

	def serialize(self, template):
		i = {
			'staff_id': self.staff_id,
			'staff_name': self.staff_name,
			'staff_position': self.staff_position,
			'staff_status': self.staff_status
		}
		lst = [None] * len(template)
		for key, value in i.items():
			for j in range(len(template)):
				if template[j] == key:
					lst[j] = value
					break
		return lst


class Items_staff(db.Model):
	__tablename__ = 'items_staff'
	
	staff_id = db.Column(db.Integer(), db.ForeignKey(Staff.staff_id), primary_key=True)
	item_id = db.Column(db.Integer(), db.ForeignKey(Items.id), primary_key=True)
	link_dt = db.Column(db.Date())

	def __init__(self, staff_id, item_id, link_dt):
		self.link_dt = link_dt
		self.staff_id = staff_id
		self.item_id = item_id

	def serialize(self, template):
		i = {
			'staff_id': self.staff_id,
			'item_id': self.item_id,
			'link_dt': self.link_dt
		}
		lst = [None] * len(template)
		for key, value in i.items():
			for j in range(len(template)):
				if template[j] == key:
					lst[j] = value
					break
		return lst


class History(db.Model):
	__tablename__ = 'history'
	
	event_id = db.Column(db.Integer(), primary_key=True)
	staff_id = db.Column(db.Integer(), db.ForeignKey(Staff.staff_id))
	item_id = db.Column(db.Integer(), db.ForeignKey(Items.id))
	event_date = db.Column(db.Date())
	event_name = db.Column(db.String())

	def __init__(self, staff_id, item_id, event_name, event_date):
		self.staff_id = staff_id
		self.item_id = item_id
		self.event_name = event_name
		self.event_date = event_date

	def serialize(self, template):
		i = {
			'event_id': self.event_id,
			'staff_id': self.staff_id,
			'item_id': self.item_id,
			'event_name': self.event_name,
			'event_date': self.event_date
		}
		lst = [None] * len(template)
		for key, value in i.items():
			for j in range(len(template)):
				if template[j] == key:
					lst[j] = value
					break
		return lst


class License(db.Model):
	__tablename__ = 'license'

	item_id = db.Column(db.Integer(), db.ForeignKey(Items.id), primary_key=True)
	l_name = db.Column(db.String())
	l_exp = db.Column(db.Date())

	def __init__(self, item_id, l_name, l_exp):
		self.item_id = item_id
		self.l_name = l_name
		self.l_exp = l_exp

	def serialize(self, template):
		i = {
			'item_id': self.item_id,
			'l_name': self.l_name,
			'l_exp': self.l_exp
		}
		lst = [None] * len(template)
		for key, value in i.items():
			for j in range(len(template)):
				if template[j] == key:
					lst[j] = value
					break
		return lst



