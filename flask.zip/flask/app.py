from flask import Flask, redirect, url_for, render_template, request, flash
from flask_sqlalchemy import SQLAlchemy

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from datetime import date

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = "postgresql:///project"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
FLASK_APP = 'PROJECT'

engine = create_engine('postgresql:///project')
db = SQLAlchemy(app)
db.create_all()
Session = (sessionmaker(autocommit=False, bind=engine))
sess = Session()

import models
import funcs as f

def shutdown_server():
    func = request.environ.get('werkzeug.server.shutdown')
    if func is None:
        raise RuntimeError('Not running with the Werkzeug Server')
    func()


@app.route('/')
def homepage():
	return render_template('hom.html')


@app.route('/useless_function')
def useless_function():
	return 'This function is onlysaa srel html ce gets chncesk doesnt rt after those already mntion events'


@app.route('/items')
def show_items():
	try:
		headers = ['ID', 'Name', 'Status', 'If it has passport', 'Place of purchase', 'Date of purchase', 'Warranty expire date']
		table_headers = ['id', 'name', 'status', 'has_passport', 'b_place', 'b_date', 'warranty']
		items = models.Items.query.all()
		items = [i.serialize(table_headers) for i in items]
				
		return render_template("show.html", items = items, headers = headers, p_color = '#eaad1c', name = 'Items')
	except Exception as e:
		sess.rollback()
		return render_template('exception.html', exception = e)

@app.route('/items/insert', methods = ['GET', 'POST'])
def insert_items():
	try:
		# INSERT PART START
		if request.method == 'POST':
			if request.form['name'] and request.form['status'] and request.form['has_passport']:
				temp = [request.form['name'], request.form['status'], request.form['has_passport'], request.form['b_place'], request.form['b_date'],  request.form['warranty']]
				for i in range(len(temp)):
					if temp[i] == "":
						temp[i] = None 
				temp[2] = temp[2] is 'TRUE'
				new_item = models.Items(temp[0], temp[1], temp[2], temp[3], temp[4], temp[5])
				sess.add(new_item)
				sess.commit()         
				return redirect(url_for('show_items'))
		# INSERT PART END	

		# SHOW PART START
		headers = ['ID', 'Name', 'Status', 'If it has passport', 'Place of purchase', 'Date of purchase', 'Warranty expire date']
		table_headers = ['id', 'name', 'status', 'has_passport', 'b_place', 'b_date', 'warranty']
		items = models.Items.query.all()
		items = [i.serialize(table_headers) for i in items]
		# SHOW PART END
				
		return render_template("insert_items.html", items = items, headers = headers)
	except Exception as e:
		sess.rollback()
		return render_template('exception.html', exception = e)
		

@app.route('/items/delete', methods = ['GET', 'POST'])
def delete_items():
	try:
		# DELETE PART START
		if request.method == 'POST':
			if request.form['id']:
				temp = request.form['id']
				sess.query(models.Items).filter(models.Items.id==temp).delete()
				sess.commit()
				return redirect(url_for('show_items'))
		# DELETE PART END	

		# SHOW PART START
		headers = ['ID', 'Name', 'Status', 'If it has passport', 'Place of purchase', 'Date of purchase', 'Warranty expire date']
		table_headers = ['id', 'name', 'status', 'has_passport', 'b_place', 'b_date', 'warranty']
		items = models.Items.query.all()
		items = [i.serialize(table_headers) for i in items]
		# SHOW PART END
				
		return render_template("delete_items.html", items = items, headers = headers)
	except Exception as e:
		sess.rollback()
		return render_template('exception.html', exception = e)


@app.route('/items/edit', methods = ['GET', 'POST'])
def edit_items():
	try:
		# EDIT PART START
		if request.method == 'POST':
			if request.form['id']:
				item = models.Items.query.filter_by(id=request.form['id'])
				item = item[0].serialize(['name', 'status', 'b_place', 'b_date', 'warranty'])
				new = [request.form['name'], request.form['status'], request.form['b_place'], request.form['b_date'], request.form['warranty']]
				for i in range(len(item)):
					if new[i]:
						item[i] = new[i]
				sess.query(models.Items).filter_by(id=request.form['id']).update({models.Items.name: item[0], models.Items.status: item[1], models.Items.b_place: item[2], models.Items.b_date: item[3], models.Items.warranty: item[4]})
				sess.commit()
				return redirect(url_for('show_items'))
		# EDIT PART END	

		# SHOW PART START
		headers = ['ID', 'Name', 'Status', 'If it has passport', 'Place of purchase', 'Date of purchase', 'Warranty expire date']
		table_headers = ['id', 'name', 'status', 'has_passport', 'b_place', 'b_date', 'warranty']
		items = models.Items.query.all()
		items = [i.serialize(table_headers) for i in items]
		# SHOW PART END

		
		return render_template("edit_items.html", items = items, headers = headers)
	except Exception as e:
		sess.rollback()
		return render_template('exception.html', exception = e)


@app.route('/staff')
def show_staff():
	try:
		headers = ['Worker ID', 'Worker name', 'Worker position']
		table_headers = ['staff_id', 'staff_name', 'staff_position']
		staff = models.Staff.query.all()
		staff = [i.serialize(table_headers) for i in staff]
				
		return render_template("show.html", items = staff, headers = headers, name = 'Staff')
	except Exception as e:
		sess.rollback()
		return render_template('exception.html', exception = e)


@app.route('/staff/insert', methods = ['GET', 'POST'])
def insert_staff():
	try:
		# INSERT PART START
		if request.method == 'POST':
			if request.form['staff_name'] and request.form['staff_position']:
				temp = [request.form['staff_name'], request.form['staff_position']]
				new_item = models.Staff(temp[0], temp[1], 1)
				sess.add(new_item)
				sess.commit()         
				return redirect(url_for('show_staff'))
		# INSERT PART END	

		# SHOW PART START
		headers = ['Worker ID', 'Worker name', 'Worker position']
		table_headers = ['staff_id', 'staff_name', 'staff_position']
		staff = models.Staff.query.all()
		staff = [i.serialize(table_headers) for i in staff]
		# SHOW PART END
				
		return render_template("insert_staff.html", items = staff, headers = headers)
	except Exception as e:
		sess.rollback()
		return render_template('exception.html', exception = e)


@app.route('/staff/delete', methods = ['GET', 'POST'])
def delete_staff():
	try:
		# DELETE PART START
		if request.method == 'POST':
			if request.form['staff_id']:
				temp = request.form['staff_id']
				sess.query(models.Staff).filter(models.Staff.staff_id==temp).delete()
				sess.commit()
				return redirect(url_for('show_staff'))
		# DELETE PART END	

		# SHOW PART START
		headers = ['Worker ID', 'Worker name', 'Worker position']
		table_headers = ['staff_id', 'staff_name', 'staff_position']
		staff = models.Staff.query.all()
		staff = [i.serialize(table_headers) for i in staff]	
		# SHOW PART END
				
		return render_template("delete_staff.html", items = staff, headers = headers)
	except Exception as e:
		sess.rollback()
		return render_template('exception.html', exception = e)


@app.route('/staff/edit', methods = ['GET', 'POST'])
def edit_staff():
	try:
		# EDIT PART START
		if request.method == 'POST':
			if request.form['staff_id']:
				staff = models.Staff.query.filter_by(staff_id=request.form['staff_id'])
				staff = staff[0].serialize(['staff_name', 'staff_position'])
				new = [request.form['staff_name'], request.form['staff_position']]
				for i in range(len(staff)):
					if new[i]:
						staff[i] = new[i]
				sess.query(models.Staff).filter_by(staff_id=request.form['staff_id']).update({models.Staff.staff_name: staff[0], models.Staff.staff_position: staff[1]})
				sess.commit()
				return redirect(url_for('show_staff'))
		# EDIT PART END	

		# SHOW PART START
		headers = ['Worker ID', 'Worker name', 'Worker position']
		table_headers = ['staff_id', 'staff_name', 'staff_position']
		staff = models.Staff.query.all()
		staff = [i.serialize(table_headers) for i in staff]
		# SHOW PART END

		
		return render_template("edit_staff.html", items = staff, headers = headers)
	except Exception as e:
		sess.rollback()
		return render_template('exception.html', exception = e)


@app.route('/items_staff')
def show_items_staff():
	try:
		headers = ['worker ID', 'Item ID', 'Link date']
		table_headers = ['staff_id', 'item_id', 'link_dt']
		i_s = models.Items_staff.query.all()
		i_s = [i.serialize(table_headers) for i in i_s]
				
		return render_template("show.html", items = i_s, headers = headers, name = 'Items_staff')
	except Exception as e:
		sess.rollback()
		return render_template('exception.html', exception = e)


@app.route('/items_staff/insert', methods = ['GET', 'POST'])
def insert_items_staff():
	try:
		# INSERT PART START
		if request.method == 'POST':
			if request.form['staff_id'] and request.form['item_id'] and request.form['link_dt']:
				temp = [request.form['staff_id'], request.form['item_id'], request.form['link_dt']]
				new_item = models.Items_staff(temp[0], temp[1], temp[2])
				sess.query(models.Items_staff).filter(models.Items_staff.staff_id==temp[0]).delete(synchronize_session='fetch')
				sess.query(models.Items_staff).filter(models.Items_staff.item_id==temp[1]).delete(synchronize_session='fetch')
				event = models.History(temp[0], temp[1], 'Linked together', date.today())
				
				sess.add(new_item)
				sess.add(event)
				sess.commit()         
				return redirect(url_for('show_items_staff'))
		# INSERT PART END

		# SHOW PART START
		headers = ['worker ID', 'Item ID', 'Link date']
		table_headers = ['staff_id', 'item_id', 'link_dt']
		i_s = models.Items_staff.query.all()
		i_s = [i.serialize(table_headers) for i in i_s]
		# SHOW PART END
				
		return render_template("insert_items_staff.html", items = i_s, headers = headers)
	except Exception as e:
		sess.rollback()
		return render_template('exception.html', exception = e)


@app.route('/items_staff/delete', methods = ['GET', 'POST'])
def delete_items_staff():
	try:
		# DELETE PART START
		if request.method == 'POST':
			if request.form['id']:
				temp = request.form['id']
				if request.form['switch'] == 'staff':
					sess.query(models.Items_staff).filter(models.Items_staff.staff_id==temp).delete()
					sess.commit()
				else:
					sess.query(models.Items_staff).filter(models.Items_staff.item_id==temp).delete()
					sess.commit()
				return redirect(url_for('show_items_staff'))
		# DELETE PART END

		# SHOW PART START
		headers = ['worker ID', 'item ID', 'Link date']
		table_headers = ['staff_id', 'item_id', 'link_dt']
		i_s = models.Items_staff.query.all()
		i_s = [i.serialize(table_headers) for i in i_s]	
		# SHOW PART END
				
		return render_template("delete_items_staff.html", items = i_s, headers = headers)
	except Exception as e:
		sess.rollback()
		return render_template('exception.html', exception = e)


@app.route('/history')
def show_history():
	try:
		headers = ['worker ID', 'Item ID', 'Event name', 'Event date']
		table_headers = ['staff_id', 'item_id', 'event_name', 'event_date']
		history = models.History.query.all()
		history = [i.serialize(table_headers) for i in history]
				
		return render_template("show.html", items = history, headers = headers, name = 'History')
	except Exception as e:
		sess.rollback()
		return render_template('exception.html', exception = e)


@app.route('/history/insert', methods = ['GET', 'POST'])
def insert_history():
	try:
		# INSERT PART START
		if request.method == 'POST':
			if request.form['staff_id'] and request.form['item_id'] and request.form['event_name'] and request.form['event_date']:
				temp = [request.form['staff_id'], request.form['item_id'], request.form['event_name'], request.form['event_date']]
				new_item = models.History(temp[0], temp[1], temp[2], temp[3])
				sess.add(new_item)
				sess.commit()
				return redirect(url_for('show_history'))
		# INSERT PART END

		# NOTE THAT USUALLY THIS TABLE IS MODIFIED OUTSIDE /history LINKS

		# SHOW PART START
		headers = ['worker ID', 'Item ID', 'Event name', 'Event date']
		table_headers = ['staff_id', 'item_id', 'event_name', 'event_date']
		history = models.History.query.all()
		history = [i.serialize(table_headers) for i in history]
		# SHOW PART END
				
		return render_template("insert_history.html", items = history, headers = headers)
	except Exception as e:
		sess.rollback()
		return render_template('exception.html', exception = e)


@app.route('/history/delete', methods = ['GET', 'POST'])
def delete_history():
	try:
		# DELETE PART START
		if request.method == 'POST':
			if request.form['id']:
				temp = request.form['id']
				sess.query(models.History).filter(models.History.event_id==temp).delete()
				sess.commit()
				return redirect(url_for('show_history'))
		# DELETE PART END

		# SHOW PART START
		headers = ['Event ID', 'worker ID', 'Item ID', 'Event name', 'Event date']
		table_headers = ['event_id', 'staff_id', 'item_id', 'event_name', 'event_date']
		history = models.History.query.all()
		history = [i.serialize(table_headers) for i in history]
		# SHOW PART END
				
		return render_template("delete_history.html", items = history, headers = headers)
	except Exception as e:
		sess.rollback()
		return render_template('exception.html', exception = e)


@app.route('/license')
def show_license():
	try:
		headers = ['Item ID', 'License name', 'License expire date']
		table_headers = ['item_id', 'l_name', 'l_exp']
		license = models.License.query.all()
		license = [i.serialize(table_headers) for i in license]
				
		return render_template("show.html", items = license, headers = headers, name = 'Licenses')
	except Exception as e:
		sess.rollback()
		return render_template('exception.html', exception = e)


@app.route('/license/insert', methods = ['GET', 'POST'])
def insert_license():
	try:
		# INSERT PART START
		if request.method == 'POST':
			if request.form['item_id'] and request.form['l_name'] and request.form['l_exp']:
				temp = [request.form['item_id'], request.form['l_name'], request.form['l_exp']]
				new_item = models.License(temp[0], temp[1], temp[2])
				sess.add(new_item)
				sess.commit()
				return redirect(url_for('show_license'))
		# INSERT PART END

		# NOTE THAT USUALLY THIS TABLE IS MODIFIED OUTSIDE /history LINKS

		# SHOW PART START
		headers = ['Item ID', 'License name', 'License expire date']
		table_headers = ['item_id', 'l_name', 'l_exp']
		license = models.License.query.all()
		license = [i.serialize(table_headers) for i in license]
		# SHOW PART END
				
		return render_template("insert_license.html", items = license, headers = headers)
	except Exception as e:
		sess.rollback()
		return render_template('exception.html', exception = e)


@app.route('/license/delete', methods = ['GET', 'POST'])
def delete_license():
	try:
		# DELETE PART START
		if request.method == 'POST':
			if request.form['id']:
				temp = request.form['id']
				sess.query(models.License).filter(models.License.item_id==temp).delete()
				sess.commit()
				return redirect(url_for('show_license'))
		# DELETE PART END	

		# SHOW PART START
		headers = ['Item ID', 'License name', 'License expire date']
		table_headers = ['item_id', 'l_name', 'l_exp']
		license = models.License.query.all()
		license = [i.serialize(table_headers) for i in license]
		# SHOW PART END
				
		return render_template("delete_license.html", items = license, headers = headers)
	except Exception as e:
		sess.rollback()
		return render_template('exception.html', exception = e)


@app.route('/license/edit', methods = ['GET', 'POST'])
def edit_license():
	try:
		# EDIT PART START
		if request.method == 'POST':
			if request.form['item_id']:
				license = models.License.query.filter_by(item_id=request.form['item_id'])
				license = license[0].serialize(['l_name', 'l_exp'])
				new = [request.form['l_name'], request.form['l_exp']]
				for i in range(len(license)):
					if new[i]:
						license[i] = new[i]
				sess.query(models.License).filter_by(item_id=request.form['item_id']).update({models.License.l_name: license[0], models.License.l_exp: license[1]})
				sess.commit()
				return redirect(url_for('show_license'))
		# EDIT PART END	

		# SHOW PART START
		headers = ['Item ID', 'License name', 'License expire date']
		table_headers = ['item_id', 'l_name', 'l_exp']
		license = models.License.query.all()
		license = [i.serialize(table_headers) for i in license]
		# SHOW PART END

		
		return render_template("edit_license.html", items = license, headers = headers)
	except Exception as e:
		sess.rollback()
		return render_template('exception.html', exception = e)


@app.route('/shutdown', methods=['GET'])
def shutdown():
    shutdown_server()
    return 'Server shutting down...'


if __name__ == '__main__':
	app.secret_key = 'A_VERY_SECRET_KEY'
	app.config['TEMPLATES_AUTO_RELOAD'] = True
	app.run(use_reloader=True)

