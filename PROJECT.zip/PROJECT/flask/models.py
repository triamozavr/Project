from app import db

class Items(db.Model):
	__tablename__ = 'item'

	id = db.Column(db.Integer, primary_key=True)
	name = db.Column(db.String())
	status = db.Column(db.String())
	has_passport = db.Column(db.Boolean())
	b_place = db.Column(db.String())
	b_date = db.Column(db.Date())
	warranty = db.Column(db.Date())

	def __init__(self, name, status, has_passport, b_place, b_date, warranty):
		self.name = name
		self.status = status
		self.has_passport = has_passport
		self.b_place = _place
		self.b_date = b_date
		self.warranty = warranty

	def __repr__(self):
		return '<id {}>'.format(self.id)
    
	def serialize(self):
		return {
			'id': self.id, 
			'name': self.name,
			'status': self.status,
			'has_passport': self.has_passport,
			'b_place': self.b_place,
			'b_date': self.b_date,
			'warranty': self.warranty
		}
