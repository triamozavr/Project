from flask import Flask, redirect, url_for, render_template
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = "postgresql:///project"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
db.create_all()

import models

@app.route('/')
def homepage():
	return """<h1>Hello world!</h1>"""

@app.route('/items')
def show_items():
	headers = ['id', 'name', 'place', 'passport', 'buyDate', 'warranty']
	return render_template('show.html',  items = models.Items.query.filter_by(id = 36).first(), headers = headers)

@app.route('/staff')
def apology2():
	print('')
	return '<html><body><h1>SORRY, BUT WE DO NOT POSESS THE KNOWLEDGE OF THE TABLE NAMED STAFF</h1><br><a href="http://localhost:5000">RETURN TO HOMEPAGE</a></body></html>'

@app.route('/items_staff')
def apology3():
	print('')
	return '<html><body><h1>SORRY, BUT WE DO NOT POSESS THE KNOWLEDGE OF THE TABLE NAMED ITEMS_and_STAFF</h1><br><a href="http://localhost:5000">RETURN TO HOMEPAGE</a></body></html>'

@app.route('/history')
def apology4():
	print('')
	return '<html><body><h1>SORRY, BUT WE DO NOT POSESS THE KNOWLEDGE OF THE TABLE NAMED HISTORY</h1><br><a href="http://localhost:5000">RETURN TO HOMEPAGE</a></body></html>'

@app.route('/license')
def apology5():
	print('')
	return '<html><body><h1>SORRY, BUT WE DO NOT POSESS THE KNOWLEDGE OF THE TABLE NAMED LICENSES</h1><br><a href="http://localhost:5000">RETURN TO HOMEPAGE</a></body></html>'


if __name__ == '__main__':
	app.run(use_reloader=True)

